/*
 * LEDS.cpp
 *
 *  Created on: 25 Jun 2019
 *      Author: jaron
 */


#include <LEDS.h>

#include "main.h"
#include "stm32l4xx_hal.h"

namespace LEDS{
	green_led::green_led(void){
		HAL_GPIO_WritePin(LED1_GPIO_Port,LED1_Pin,GPIO_PIN_SET);
	}
	green_led::~green_led(void){
		HAL_GPIO_WritePin(LED1_GPIO_Port,LED1_Pin,GPIO_PIN_RESET);
	}


	red_led::red_led(void){
		HAL_GPIO_WritePin(LED2_GPIO_Port,LED2_Pin,GPIO_PIN_SET);
	}
	red_led::~red_led(void){
		HAL_GPIO_WritePin(LED2_GPIO_Port,LED2_Pin,GPIO_PIN_RESET);
	}

	void blink_red(void){
		red_led rl;
		HAL_Delay(20);
	}

	void blink_green(void){
		green_led gl;
		HAL_Delay(20);
	}

	void timer_trigger(TIM_HandleTypeDef* htim){
		// todo
	}
}

