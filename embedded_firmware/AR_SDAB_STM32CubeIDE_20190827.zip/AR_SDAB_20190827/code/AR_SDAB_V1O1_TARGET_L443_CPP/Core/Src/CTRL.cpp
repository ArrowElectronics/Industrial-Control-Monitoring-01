/*
 * CTRL.cpp
 *
 *  Created on: 21 Jun 2019
 *      Author: jaron
 */

#include <CTRL.h>

#include <LTC2983.h>
#include <serial_debug.h>

#include <set>

namespace CTRL{
namespace{
	enum class timedness{
		Idle,
		Timed_periodic,
	};
	TIM_HandleTypeDef* CTRL_timer;
	uint32_t CTRL_timer_channel;

	LTC2983::ch_conf_regset ch_config = {};
	ch_single single_ch_enable;
	std::set<uint8_t> periodic_chs_enable;
	std::set<uint8_t>::iterator next_ch;
	bool periodic_meas_flag;
	timedness timed_state;
	uint16_t rate_counter;
	}

void init(TIM_HandleTypeDef* tim, uint32_t channel){
	CTRL_timer = tim;
	CTRL_timer_channel = channel;

	timed_state = timedness::Idle;
}

void configure_channel(ch_config_desc conf){
	ch_config[conf.ch] = conf.raw_conf;
	LTC2983::configure_channel(conf.ch, conf.raw_conf);
}

void enable_channels(ch_enable chs){
	periodic_chs_enable.clear();
	for(int i = 0; i < LTC2983::numof_channels; i++){
		if((chs>>i) & 1){
			periodic_chs_enable.insert(i+1);
		}
	}
	next_ch = periodic_chs_enable.begin();
}

void start_single(ch_single ch){
	if(LTC2983::channel_valid(ch)){
		single_ch_enable = ch;
	}
}

void start_periodic(void){
	switch(timed_state){
	case timedness::Idle:
		periodic_meas_flag = true;
		timed_state = timedness::Timed_periodic;
		HAL_TIM_OC_Start_IT(CTRL_timer, CTRL_timer_channel);
		break;
	default:
		break;
	}
}

void timer_trigger(TIM_HandleTypeDef* tim){
	if(CTRL_timer->Instance == tim->Instance){
		HAL_TIM_OC_Stop(CTRL_timer, CTRL_timer_channel);

		periodic_meas_flag = true;

		CTRL_timer->Init.Period = rate_counter;
		if (HAL_TIM_OC_Init(CTRL_timer) != HAL_OK)
		{
			_Error_Handler(__FILE__, __LINE__);
		}
		HAL_TIM_OC_Start_IT(CTRL_timer, CTRL_timer_channel);
	}
}

void stop_periodic(void){
	timed_state = timedness::Idle;
	HAL_TIM_OC_Stop(CTRL_timer,CTRL_timer_channel);
	periodic_meas_flag = false;
}

void set_periodic_rate(period_seconds rate_config){
	switch(rate_config){
	case period_seconds::One:
		rate_counter = 1000;
		break;
	case period_seconds::Two:
		rate_counter = 2000;
		break;
	case period_seconds::Five:
		rate_counter = 5000;
		break;
	case period_seconds::Ten:
		rate_counter = 10000;
		break;
	case period_seconds::Thirty:
		rate_counter = 30000;
		break;
	case period_seconds::Sixty:
		rate_counter = 60000;
		break;
	default:
		break;
	}
}

uint8_t meas_required_on_channel(void){
	uint8_t ret;
	if(single_ch_enable){
		ret = single_ch_enable;
		single_ch_enable = 0;
	}
	else if(periodic_meas_flag && (periodic_chs_enable.size() != 0)){
		ret = *next_ch;
		next_ch++;
		if(periodic_chs_enable.end() == next_ch){
			next_ch = periodic_chs_enable.begin();
		}
		periodic_meas_flag = false;
	}
	else{
		ret = 0;
	}
	return ret;
}



}
