/*
 * serial_debug.cpp
 *
 *  Created on: 14 Jun 2019
 *      Author: jaron
 */

#include <serial_debug.h>

namespace serial_debug {

	namespace {
		UART_HandleTypeDef* debug_UART;
	}

	void init(UART_HandleTypeDef* huart){
		debug_UART = huart;
	}
	void send(std::string msg){
		char linefeed[] = {'\r','\n'};
		HAL_UART_Transmit(debug_UART, (uint8_t*)msg.c_str(), msg.size(), HAL_MAX_DELAY);
		HAL_UART_Transmit(debug_UART, (uint8_t*)&linefeed, sizeof(linefeed), HAL_MAX_DELAY);
	}
}
