/*
 * LTC2983.cpp
 *
 *  Created on: 13 Jun 2019
 *      Author: jaron
 */

#include <LTC2983.h>
#include <serial_debug.h>
#include <spi_token.h>
#include <byte.h>

namespace LTC2983 {
	bool channel_valid(uint8_t ch){
		return (1 <= ch) && (numof_channels >= ch);
	}
	namespace{
		SPI_HandleTypeDef* LTC_SPI;
		bool conversion_flag;

		uint8_t ltc_read = 0b00000011;
		uint8_t ltc_write = 0b00000010;

		uint16_t channel_config_addr(uint8_t ch){
			return 0x200 + 4*(uint16_t)(ch-1);
		}
		uint16_t channel_result_addr(uint8_t ch){
			return 0x010 + 4*(uint16_t)(ch-1);
		}
		uint8_t channel_conv_starter(uint8_t ch){
			return 0b10000000 + ch;
		}

		void start_conversion(uint8_t ch){
			spi_token tok{spi_dev::LTC};

			uint16_t addr = byte::swap(0);
			uint8_t starter = channel_conv_starter(ch);

			HAL_SPI_Transmit(LTC_SPI, &ltc_write, sizeof(ltc_write), HAL_MAX_DELAY);
			HAL_SPI_Transmit(LTC_SPI, (uint8_t*)&addr, sizeof(addr), HAL_MAX_DELAY);
			HAL_SPI_Transmit(LTC_SPI, (uint8_t*)&starter, sizeof(starter), HAL_MAX_DELAY);

			conversion_flag = false;
		}

		uint32_t read_measurement(uint8_t ch){
			spi_token tok{spi_dev::LTC};

			uint16_t addr = byte::swap(channel_result_addr(ch));
			uint32_t ret = 0;

			HAL_SPI_Transmit(LTC_SPI, &ltc_read, sizeof(ltc_read), HAL_MAX_DELAY);
			HAL_SPI_Transmit(LTC_SPI, (uint8_t*)&addr, sizeof(addr), HAL_MAX_DELAY);
			HAL_SPI_Receive(LTC_SPI, (uint8_t*)&ret, sizeof(ret), HAL_MAX_DELAY);

			ret = byte::swap(ret);
			return ret;
		}
	}

	void init(SPI_HandleTypeDef* hspi){
		LTC_SPI = hspi;
		HAL_Delay(1000);	// LTC IC needs at least 200 ms wait before communication
	}

	void configure_channel(uint8_t ch, uint32_t raw_config){
		if(channel_valid(ch)){
			spi_token tok{spi_dev::LTC};

			uint16_t addr = byte::swap(channel_config_addr(ch));
			uint32_t config = byte::swap(raw_config);

			HAL_SPI_Transmit(LTC_SPI, &ltc_write, sizeof(ltc_write), HAL_MAX_DELAY);
			HAL_SPI_Transmit(LTC_SPI, (uint8_t*)&addr, sizeof(addr), HAL_MAX_DELAY);
			HAL_SPI_Transmit(LTC_SPI, (uint8_t*)&config, sizeof(config), HAL_MAX_DELAY);
		}
	}

	void conversion_done(void){
		conversion_flag = true;
	}

	uint32_t measure(uint8_t ch){
		uint32_t ret = -1;
		if(channel_valid(ch)){
			start_conversion(ch);
			while(!conversion_flag);
			ret = read_measurement(ch);
		}
		return ret;
	}

	uint8_t result_flags(uint32_t dirmeas){
		return (uint8_t)(dirmeas>>24);
	}
	uint32_t result_temp(uint32_t dirmeas){
		uint32_t ret;
		ret = dirmeas & 0x00FFFFFF;
		ret |= (ret & 0x00800000)? 0xFF000000 : 0;

		return ret;
	}
}
