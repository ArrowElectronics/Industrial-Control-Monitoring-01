/*
 * RS485.cpp
 *
 *  Created on: 13 Jun 2019
 *      Author: jaron
 */


#include <RS485.h>
#include <CTRL.h>
#include <serial_debug.h>

#include <byte.h>
#include <dir_token.h>

namespace RS485{
	namespace{
	UART_HandleTypeDef* RS485_UART;
	uint8_t raw_input_buffer[1024];
	uint8_t* buffer_pos = raw_input_buffer;

	CTRL::ch_single pack_single_ch(uint8_t const* inpos){
		uint8_t* pos = const_cast<uint8_t*>(inpos);

		CTRL::ch_single ret;
		ret = *(CTRL::ch_single*)pos;
		ret = byte::swap(ret);

		return ret;
	}
	CTRL::ch_config_desc pack_config(uint8_t const* inpos){
		// danger, out of range?
		uint8_t* pos = const_cast<uint8_t*>(inpos);

		CTRL::ch_config_desc ret;
		ret.ch = *(CTRL::ch_single*)pos;
		ret.ch = byte::swap(ret.ch);
		pos++;

		ret.raw_conf = *(uint32_t*)pos;
		ret.raw_conf = byte::swap(ret.raw_conf);

		return ret;
	}
	CTRL::ch_enable pack_enable(uint8_t const* inpos){
		// danger, out of range?
		uint8_t* pos = const_cast<uint8_t*>(inpos);

		CTRL::ch_enable ret;

		ret = *(CTRL::ch_enable*)pos;
		ret = byte::swap(ret);
		ret &= 0x000FFFFF;

		return ret;
	}
	CTRL::period_seconds pack_rate(uint8_t const* inpos){
		// danger, out of range?
		uint8_t* pos = const_cast<uint8_t*>(inpos);

		CTRL::period_seconds ret;
		ret = static_cast<CTRL::period_seconds>(*pos);
		switch(ret){
		case CTRL::period_seconds::One:
		case CTRL::period_seconds::Two:
		case CTRL::period_seconds::Five:
		case CTRL::period_seconds::Ten:
		case CTRL::period_seconds::Thirty:
		case CTRL::period_seconds::Sixty:
			break;
		default:
			ret = CTRL::period_seconds::Two;
			break;
		}
		return ret;
	}
	}


	void receive(){
		buffer_pos = raw_input_buffer;
		while(HAL_GPIO_ReadPin(DIP1_GPIO_Port,DIP1_Pin)){
			if(HAL_OK == HAL_UART_Receive(RS485_UART,buffer_pos,1,100)){
				buffer_pos++;
			}
		}
	}

	void process_recv_buffer(){
		uint8_t* pos = raw_input_buffer;
		OpCodes opc;
		while(pos < buffer_pos){
			opc = static_cast<OpCodes>(*pos);
			pos++;

			switch(opc){
			case OpCodes::START_MEAS:
				CTRL::start_single(pack_single_ch(pos));
				break;
			case OpCodes::START_PERIODIC:
				CTRL::start_periodic();
				break;
			case OpCodes::STOP_PERIODIC:
				CTRL::stop_periodic();
				break;

			case OpCodes::ENABLE_CH:
				CTRL::enable_channels(pack_enable(pos));
				pos += sizeof(CTRL::ch_enable);
				break;
			case OpCodes::RAW_CH_CONFIG:
				CTRL::configure_channel(pack_config(pos));
				pos += 5; // TODO !!! skull and bones
				break;
			case OpCodes::SAMPLE_RATE:
				CTRL::set_periodic_rate(pack_rate(pos));
				pos += sizeof(CTRL::period_seconds);
				break;
			default:
				break;
			}
		}
	}

	void init(UART_HandleTypeDef* huart){
		RS485_UART = huart;
		HAL_GPIO_WritePin(RS485_EN_GPIO_Port, RS485_EN_Pin, GPIO_PIN_SET);
	}

	void transmit_measurement(uint8_t ch, int32_t meas){
		dir_token tok;

		int32_t swapped_meas = byte::swap(meas);
		uint8_t opc = static_cast<uint8_t>(OpCodes::MEAS_RESULTS);

		HAL_UART_Transmit(RS485_UART, &opc, sizeof(opc), HAL_MAX_DELAY);
		HAL_UART_Transmit(RS485_UART, &ch, sizeof(ch), HAL_MAX_DELAY);
		HAL_UART_Transmit(RS485_UART, (uint8_t*)&swapped_meas, sizeof(swapped_meas), HAL_MAX_DELAY);

	}

	void transmit_error(uint8_t ch, uint8_t errorflags){
		dir_token tok;

		uint8_t opc = static_cast<uint8_t>(OpCodes::MEAS_ERROR);

		HAL_UART_Transmit(RS485_UART, &opc, sizeof(opc), HAL_MAX_DELAY);
		HAL_UART_Transmit(RS485_UART, &ch, sizeof(ch), HAL_MAX_DELAY);
		HAL_UART_Transmit(RS485_UART, &errorflags, sizeof(errorflags), HAL_MAX_DELAY);
	}
}

