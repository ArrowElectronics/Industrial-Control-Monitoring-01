/*
 * LTC2983.h
 *
 *  Created on: 13 Jun 2019
 *      Author: jaron
 */

#ifndef INC_LTC2983_H_
#define INC_LTC2983_H_

#include "main.h"
#include "stm32l4xx_hal.h"

#include <array>

namespace LTC2983 {
	enum class flags : uint8_t{
		Valid = 0x01
	};
	uint8_t result_flags(uint32_t dirmeas);
	uint32_t result_temp(uint32_t dirmeas);

	const uint8_t numof_channels = 20;
	typedef std::array<uint32_t, numof_channels> ch_conf_regset;
	bool channel_valid(uint8_t ch);

	void init(SPI_HandleTypeDef* hspi);
	void configure_channel(uint8_t ch, uint32_t raw_config);
	void conversion_done(void);
	uint32_t measure(uint8_t ch);
}


#endif /* INC_LTC2983_H_ */
