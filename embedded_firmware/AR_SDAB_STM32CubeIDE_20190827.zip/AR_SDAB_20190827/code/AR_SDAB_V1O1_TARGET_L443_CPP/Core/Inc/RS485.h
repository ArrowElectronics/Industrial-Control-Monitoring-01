/*
 * RS485.h
 *
 *  Created on: 13 Jun 2019
 *      Author: jaron
 */

#ifndef INC_RS485_H_
#define INC_RS485_H_

#include "main.h"
#include "stm32l4xx_hal.h"

namespace RS485 {
	enum class OpCodes : uint8_t {
		RAW_CH_CONFIG = 0xF0,
		ENABLE_CH,
		SAMPLE_RATE,
		START_MEAS,
		START_PERIODIC,
		STOP_PERIODIC,
		MEAS_RESULTS,
		MEAS_ERROR
	};

	void receive(void);
	void process_recv_buffer(void);

	void init(UART_HandleTypeDef* huart);
	void transmit_measurement(uint8_t ch, int32_t meas);
	void transmit_error(uint8_t ch, uint8_t errorflags);
};


#endif /* INC_RS485_H_ */
