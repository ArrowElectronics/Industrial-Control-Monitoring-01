/*
 * LEDS.h
 *
 *  Created on: 25 Jun 2019
 *      Author: jaron
 */

#ifndef INC_LEDS_H_
#define INC_LEDS_H_

#include "main.h"
#include "stm32l4xx_hal.h"

namespace LEDS{
class green_led{
public:
	green_led(void);
	~green_led(void);
private:
	green_led& operator=(green_led&) = delete;
	green_led& operator=(green_led&&) = delete;
	green_led(green_led&) = delete;
	green_led(green_led&&) = delete;
};
class red_led{
public:
	red_led(void);
	~red_led(void);
private:
	red_led& operator=(red_led&) = delete;
	red_led& operator=(red_led&&) = delete;
	red_led(red_led&) = delete;
	red_led(red_led&&) = delete;
};

void blink_green(void);
void blink_red(void);

void timer_trigger(TIM_HandleTypeDef* htim);
}


#endif /* INC_LEDS_H_ */
