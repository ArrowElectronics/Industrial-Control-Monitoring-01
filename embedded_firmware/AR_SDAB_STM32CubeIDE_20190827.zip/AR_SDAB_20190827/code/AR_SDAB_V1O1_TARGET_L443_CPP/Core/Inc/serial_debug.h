/*
 * serial_debug.h
 *
 *  Created on: 14 Jun 2019
 *      Author: jaron
 */

#ifndef INC_SERIAL_DEBUG_H_
#define INC_SERIAL_DEBUG_H_

#include "main.h"
#include "stm32l4xx_hal.h"

#include <string>

namespace serial_debug{
	void init(UART_HandleTypeDef* huart);
	void send(std::string msg);
}

#endif /* INC_SERIAL_DEBUG_H_ */
