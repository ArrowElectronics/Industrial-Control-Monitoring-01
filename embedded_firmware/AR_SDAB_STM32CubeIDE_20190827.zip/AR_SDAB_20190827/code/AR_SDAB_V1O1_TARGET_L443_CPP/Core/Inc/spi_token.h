/*
 * spi_token.h
 *
 *  Created on: 20 Jun 2019
 *      Author: jaron
 */

#ifndef INC_SPI_TOKEN_H_
#define INC_SPI_TOKEN_H_

#include "main.h"
#include "stm32l4xx_hal.h"

namespace LTC2983{
namespace{
enum class spi_dev{
	LTC = LTC_SPI_nSS_Pin,
	PIPE = PIPE_SPI_nSS_Pin
};
class spi_token{
	spi_token() = delete;
	spi_token(const spi_token&) = delete;
	spi_token operator=(const spi_token&) = delete;
	spi_token(spi_token&&) = delete;
	spi_token operator=(spi_token&&) = delete;
private:
	spi_dev locked;
public:
	spi_token(spi_dev d){
		locked = d;
		switch(locked){
		case spi_dev::LTC:
			HAL_GPIO_WritePin(LTC_SPI_nSS_GPIO_Port,LTC_SPI_nSS_Pin,GPIO_PIN_RESET);
			break;
		case spi_dev::PIPE:
			HAL_GPIO_WritePin(PIPE_SPI_nSS_GPIO_Port,PIPE_SPI_nSS_Pin,GPIO_PIN_RESET);
			break;
		default:
			break;
		}
	}
	~spi_token(){
		switch(locked){
		case spi_dev::LTC:
			HAL_GPIO_WritePin(LTC_SPI_nSS_GPIO_Port,LTC_SPI_nSS_Pin,GPIO_PIN_SET);
			break;
		case spi_dev::PIPE:
			HAL_GPIO_WritePin(PIPE_SPI_nSS_GPIO_Port,PIPE_SPI_nSS_Pin,GPIO_PIN_SET);
			break;
		default:
			break;
		}
	}
};
}
}

#endif /* INC_SPI_TOKEN_H_ */
