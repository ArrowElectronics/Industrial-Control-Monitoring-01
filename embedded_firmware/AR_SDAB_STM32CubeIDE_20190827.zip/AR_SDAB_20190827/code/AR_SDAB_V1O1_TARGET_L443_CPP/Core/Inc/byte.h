/*
 * byte.h
 *
 *  Created on: 18 Jun 2019
 *      Author: jaron
 */

#ifndef INC_BYTE_H_
#define INC_BYTE_H_

namespace byte{

template <typename T>
T swap(T d){
	T ret = 0;
	int siz = sizeof(T);
	for(int i=0; i<siz; i++){
		ret |= ((d>>(8*i))&0xFF)<<(8*(siz-i-1));
	}
	return ret;
}

}

#endif /* INC_BYTE_H_ */
