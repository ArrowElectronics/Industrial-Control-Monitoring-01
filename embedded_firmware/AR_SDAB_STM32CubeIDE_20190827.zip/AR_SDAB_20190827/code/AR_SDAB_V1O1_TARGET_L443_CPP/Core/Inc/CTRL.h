/*
 * CTRL.h
 *
 *  Created on: 21 Jun 2019
 *      Author: jaron
 */

#ifndef INC_CTRL_H_
#define INC_CTRL_H_

#include "main.h"
#include "stm32l4xx_hal.h"

#include <array>

namespace CTRL{
	enum class period_seconds : uint8_t{
		One = 1,
		Two,
		Five,
		Ten,
		Thirty,
		Sixty
	};
	typedef uint32_t ch_enable;
	typedef uint8_t ch_single;
	struct ch_config_desc{
		ch_single ch;
		uint32_t raw_conf;
	};

	void init(TIM_HandleTypeDef* tim, uint32_t channel);

	void timer_trigger(TIM_HandleTypeDef* tim);

	void configure_channel(ch_config_desc conf);
	void enable_channels(ch_enable chs);

	void start_single(ch_single ch);
	void start_periodic(void);
	void stop_periodic(void);
	void set_periodic_rate(period_seconds rate_config);

	uint8_t meas_required_on_channel(void);
}

#endif /* INC_CTRL_H_ */
