/*
 * dir_token.h
 *
 *  Created on: 20 Jun 2019
 *      Author: jaron
 */

#ifndef INC_DIR_TOKEN_H_
#define INC_DIR_TOKEN_H_

#include "main.h"
#include "stm32l4xx_hal.h"

namespace RS485{
namespace{
class dir_token{
	dir_token(const dir_token&) = delete;
	dir_token operator=(const dir_token&) = delete;
	dir_token(dir_token&&) = delete;
	dir_token operator=(dir_token&&) = delete;

public:
	dir_token(){
		HAL_GPIO_WritePin(RS485_DIR_GPIO_Port,RS485_DIR_Pin,GPIO_PIN_SET);
	}
	~dir_token(){
		HAL_GPIO_WritePin(RS485_DIR_GPIO_Port,RS485_DIR_Pin,GPIO_PIN_RESET);
	}

};
}
}

#endif /* INC_DIR_TOKEN_H_ */
